"""
Available on https://github.com/ptandeo/CEDA
@author: Pierre Tandeo

"""

import numpy as np
from algos.utils import RMSE, inv_svd
from numpy.linalg import inv
from tqdm import tqdm

def _likelihood(Xf, Pf, obs, R, H):
  T = Xf.shape[1]
  l = 0
  for t in range(T):
    if not np.isnan(obs[0,t]):
      sig = H[:,:,t].dot(Pf[:,:,t]).dot(H[:,:,t].T) + R
      innov = obs[:,t] - H[:,:,t].dot(Xf[:,t])
      l -= .5 * np.log(2*np.pi*np.linalg.det(sig)) ### MODIF TRANG ###
      l -= .5 * innov.T.dot(np.linalg.solve(sig, innov))
  return l

def _EKF(dx, dy, T, xb, B, Q, R, obs, f, jacF, h, jacH, alpha):
  Xa = np.zeros((dx, T+1))
  Xf = np.zeros((dx, T))
  Pa = np.zeros((dx, dx, T+1))
  Pf = np.zeros((dx, dx, T))
  F_all = np.zeros((dx, dx, T))
  H_all = np.zeros((dy, dx, T))

  x = xb; Xa[:,0] = x
  P = B; Pa[:,:,0] = P
  for t in range(T):
    # Forecast
    F = jacF(x)
    x = f(x)
    P = F.dot(P).dot(F.T) + Q
    P = .5*(P + P.T)

    Pf[:,:,t]=P; Xf[:,t]=x; F_all[:,:,t]=F

    # Update
    if not np.isnan(obs[0,t]):
      H = jacH(x)
      d = obs[:,t] - h(x)
      S = H.dot(P).dot(H.T) + R/alpha
      K = P.dot(H.T).dot(inv(S))
      P = (np.eye(dx) - K.dot(H)).dot(P)
      x = x + K.dot(d)

    Pa[:,:,t+1]=P; Xa[:,t+1]=x; H_all[:,:,t]=H

  return Xa, Pa, Xf, Pf, F_all, H_all, K

def _EKS(dx, dy, T, xb, B, Q, R, obs, f, jacF, h, jacH, alpha):
  Xa, Pa, Xf, Pf, F, H, Kf_final = _EKF(dx, dy, T, xb, B, Q, R, obs, f,
                                         jacF, h, jacH, alpha)

  Xs = np.zeros((dx, T+1))
  Ps = np.zeros((dx, dx, T+1))
  K_all = np.zeros((dx, dx, T))

  x = Xa[:,-1]; Xs[:,-1] = x
  P = Pa[:,:,-1]; Ps[:,:,-1] = P
  for t in range(T-1, -1, -1):
    K = Pa[:,:,t].dot(F[:,:,t].T).dot(inv(Pf[:,:,t]))
    x = Xa[:,t] + K.dot(x - Xf[:,t])
    P = Pa[:,:,t] - K.dot(Pf[:,:,t] - P).dot(K.T)

    Ps[:,:,t]=P; Xs[:,t]=x; K_all[:,:,t]=K

  Ps_lag = np.zeros((dx, dx, T))
  Ps_lag[:,:,-1] = ((np.eye(dx)-Kf_final.dot(H[:,:,-1]))
                  .dot(F[:,:,-1]).dot(Pa[:,:,-2]))
  for t in range(T-2, -1, -1):
    Ps_lag[:,:,t] += Pa[:,:,t+1].dot(K_all[:,:,t].T)
    Ps_lag[:,:,t] += (K_all[:,:,t+1]
                   .dot(Ps_lag[:,:,t+1] - F[:,:,t+1].dot(Pa[:,:,t+1]))
                   .dot(K_all[:,:,t].T))

  return Xs, Ps, Ps_lag, Xa, Pa, Xf, Pf, H

def _maximize(Xs, Ps, Ps_lag, obs, h, jacH, f, jacF, structQ='full', baseQ=None, structR='full', baseR=None):
  T = obs.shape[1]
  dx = Xs.shape[0]
  dy = obs.shape[0]
  baseQ = np.eye(dx)
  xb = Xs[:,0]
  B = Ps[:,:,0]

  R = np.zeros((dy,dy))
  nobs = 0
  for t in range(T):
    if not np.isnan(obs[0,t]):
      nobs += 1
      H = jacH(Xs[:,t+1])
      R += np.outer(obs[:,t] - h(Xs[:,t+1]), obs[:,t] - h(Xs[:,t+1]))
      R += H.dot(Ps[:,:,t+1]).dot(H.T)
  R = .5*(R + R.T)
  R /= nobs
  ### MODIF TRANG ###
  if structR == 'full':
    R = R
  elif structR == 'diag':
    R = np.diag(np.diag(R))
  elif structR == 'const':
    R = baseR*np.trace(inv_svd(baseR).dot(R))/dy
 
  sumSig = np.zeros((dx,dx))
  for t in range(T):
    F = jacF(Xs[:,t+1])
    sumSig += Ps[:,:,t+1]
    sumSig += np.outer(Xs[:,t+1]-f(Xs[:,t]), Xs[:,t+1]-f(Xs[:,t]))
    sumSig += F.dot(Ps[:,:,t]).dot(F.T)
    sumSig -= Ps_lag[:,:,t].dot(F.T) + F.dot(Ps_lag[:,:,t].T)
  if structQ == 'full':
    Q = sumSig/T
  elif structQ == 'diag':
    Q = np.diag(np.diag(sumSig))/T
  elif structQ == 'const':
    Q = baseQ*np.trace(inv_svd(baseQ).dot(sumSig)) / (T*dx)

  return xb, B, Q, R

def EKS(params):
  obs = params['observations']
  xb = params['background_state']
  B  = params['background_covariance']
  Q  = params['model_noise_covariance']
  R  = params['observation_noise_covariance']
  f  = params['model_dynamics']
  jacF = params['model_jacobian']
  h  = params['observation_operator']
  jacH = params['observation_jacobian']
  dx = params['state_size']
  dy = params['observation_size']
  T  = params['temporal_window_size']
  Xt = params['true_state']
  alpha = params['inflation_factor']

  Xs, Ps, Ps_lag, Xa, Pa, Xf, Pf, H = _EKS(dx, dy, T, xb, B, Q, R, obs, f,
                                           jacF, h, jacH, alpha)
  l = _likelihood(Xf, Pf, obs, R, H)

  res = {
          'smoothed_states'            : Xs,
          'smoothed_covariances'       : Ps,
          'smoothed_lagged_covariances': Ps_lag,
          'analysis_states'            : Xa,
          'analysis_covariance'        : Pa,
          'forecast_states'            : Xf,
          'forecast_covariance'        : Pf,
          'RMSE'                       : RMSE(Xs[:,1:] - Xt[:,1:]),
          'params'                     : params,
          'loglikelihood'              : l
        }
  return res

def EKS_EM(params):
  xb    = params['initial_background_state']
  B     = params['initial_background_covariance']
  Q     = params['initial_model_noise_covariance']
  R     = params['initial_observation_noise_covariance']
  f     = params['model_dynamics']
  jacF  = params['model_jacobian']
  h     = params['observation_operator']
  jacH  = params['observation_jacobian']
  obs    = params['observations']
  nIter = params['nb_EM_iterations']
  gam0 = params['step_function_SAEM']
  Xt    = params['true_state']
  dx    = params['state_size']
  dy    = params['observation_size']
  T     = params['temporal_window_size']
  alpha = params['inflation_factor']
  estimateQ  = params['is_model_noise_covariance_estimated']
  estimateR  = params['is_observation_noise_covariance_estimated']
  estimateX0 = params['is_background_estimated']
  structQ = params['model_noise_covariance_structure']
  structR = params['observation_noise_covariance_structure']
  baseQ = params['model_noise_covariance_matrix_template']
  baseR = params['observation_noise_covariance_matrix_template']


  loglik = np.zeros(nIter)
  rmse_em = np.zeros(nIter)

  Q_all  = np.zeros(np.r_[Q.shape, nIter+1])
  R_all  = np.zeros(np.r_[R.shape, nIter+1])
  B_all  = np.zeros(np.r_[B.shape, nIter+1])
  xb_all = np.zeros(np.r_[xb.shape, nIter+1])

  Xs_all = np.zeros([dx, T+1, nIter])

  Q_all[:,:,0] = Q
  R_all[:,:,0] = R
  xb_all[:,0]  = xb
  B_all[:,:,0] = B

  for k in (range(nIter)):

    # Expectation (E)-step
    Xs, Ps, Ps_lag, Xa, Pa, Xf, Pf, H = _EKS(dx, dy, T, xb, B, Q, R, obs, f, jacF,
                                             h, jacH, alpha)
    loglik[k] = _likelihood(Xf, Pf, obs, R, H)
    rmse_em[k] = RMSE(Xs[:,1:] - Xt[:,1:])
    Xs_all[...,k] = Xs

    # Maximization (M)-step
    xb_new, B_new, Q_new, R_new = _maximize(Xs, Ps, Ps_lag, obs, h, jacH, f, jacF,
                            structQ=structQ, baseQ=baseQ, structR=structR, baseR=baseR)
    if estimateQ:
      Q = Q_new
    if estimateR:
      R = R_new
    if estimateX0:
      xb = xb_new
      B = B_new
    
    gam = gam0[k]
    Q_all[:,:,k+1] = gam*Q + (1-gam)*Q_all[:,:,k] 
    R_all[:,:,k+1] = gam*R + (1-gam)*R_all[:,:,k] 
    xb_all[:,k+1] = gam*xb + (1-gam)*xb_all[:,k] 
    B_all[:,:,k+1] = gam*B + (1-gam)*B_all[:,:,k] 
    '''
    Q_all[:,:,k+1] = Q
    R_all[:,:,k+1] = R
    xb_all[:,k+1] = xb
    B_all[:,:,k+1] = B
    '''
  res = {
          'smoothed_states'                : Xs_all,
          'EM_background_state'            : xb_all,
          'EM_background_covariance'       : B_all,
          'EM_model_noise_covariance'      : Q_all,
          'EM_observation_noise_covariance': R_all, 
          'loglikelihood'                  : loglik,
          'RMSE'                           : rmse_em, 
          'params'                         : params
        }
  return res
