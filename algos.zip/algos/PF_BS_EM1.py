#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Thi Tuyet Trang Chau

"""

import numpy as np
from multiprocessing import Pool
from numpy.linalg import inv
from scipy.integrate import ode
import numpy as np
from algos.utils import RMSE, inv_svd, sqrt_svd, sampling_discrete, resampling_sys
from tqdm import tqdm

def _maximize(X, obs, H, f, structQ='full', baseQ=None, structR='full', baseR=None):
  
  dx, Ns, T = X.shape
  dy = obs.shape[0]
  baseQ = np.eye(dx)
  xb = np.mean(X[:,:,0], 1)
  B = np.cov(X[:,:,0])

  sumSig = np.zeros((dx, Ns, T-1))
  for t in range(T-1):
    sumSig[...,t] = X[...,t+1] - f(X[...,t])
  sumSig = np.reshape(sumSig, (dx, (T-1)*Ns))
  sumSig = sumSig.dot(sumSig.T) / Ns
  if structQ == 'full':
    Q = sumSig/(T-1)
  elif structQ == 'diag':
    Q = np.diag(np.diag(sumSig))/T
  elif structQ == 'const':
    Q = baseQ*np.trace(inv_svd(baseQ).dot(sumSig)) / ((T-1)*dx)
    
  W = np.zeros([dy, Ns, T-1])
  nobs = 0
  for t in range(T-1):
    if not np.isnan(obs[0,t]): 
      nobs += 1
      W[:,:,t] = np.tile(obs[:,t], (Ns, 1)).T - H.dot(X[:,:,t+1])
  W = np.reshape(W, (dy, (T-1)*Ns))
  R = W.dot(W.T) / (nobs*Ns)
  if structR == 'full':
    R = R
  elif structR == 'diag':
    R = np.diag(np.diag(R))
  elif structR == 'const':
    R = baseR*np.trace(inv_svd(baseR).dot(R))/dy
  
  return xb, B, Q, R  

def _likelihood(Xf, obs, H, R):
  T = Xf.shape[2]

  x = np.mean(Xf, 1)

  l = 0
  for t in range(T):
    if not np.isnan(obs[0,t]):
      innov = obs[:, t] - H.dot(x[:, t])
      Y = H.dot(Xf[:, :, t])

      sig = np.cov(Y) + R
      l -= .5 * np.log(2*np.pi*np.linalg.det(sig))     
      l -= .5 * innov.T.dot(inv(sig)).dot(innov)
  return l

def _PF(dx, T, dy, xb, B, Q, R, Nf, f, H, obs, prng): 
    sqQ = sqrt_svd(Q)
    sqR = sqrt_svd(R)
    sqB = sqrt_svd(B)
    Xa = np.zeros([dx, Nf, T+1])
    Xf = np.zeros([dx, Nf, T])
    Xf_mean = np.zeros([dx, Nf, T+1])
    Wa = np.zeros([Nf, T+1])
    Wa[:,0] = 1/Nf*np.ones(Nf) 
    # Initialize ensemble
    for i in range(Nf):
        Xa[:,i,0] = xb + sqB.dot(prng.normal(size=dx))
    for t in range(T):
        # Resampling
        ind = resampling_sys(Wa[:,t])
        
        # Forecasting
        Xf_mean[:,:,t+1] = f(Xa[:,:,t])
        Xf[:,:,t] = Xf_mean[:,ind,t+1]+ sqQ.dot(prng.normal(size=(dx, Nf)))
        Xa[:,:,t+1] = Xf[:,:,t]

        # Weighting
        ind_unobs = np.where(np.isnan(obs[:,t]))
        if np.size(ind_unobs) == dx:
            Wa[:,t+1] = 1/Nf*np.ones([Nf]) 
        else:
            Y = H.dot(Xa[:,:,t+1]) 
            innov = np.tile(obs[:,t], (Nf,1)).T - Y
            logmax = np.max(-.5 *np.sum(innov.T.dot(inv(R))*(innov.T),1)) # for numerical stability
            #const = np.sqrt(2*np.pi*np.linalg.det(R))
            Wa[:,t+1] = np.exp(-.5 *np.sum(innov.T.dot(inv(R))*(innov.T),1) - logmax)#*Wa_prev
            Wa[:,t+1] = Wa[:,t+1]/np.sum(Wa[:,t+1])
    return Xa, Xf, Xf_mean, Wa

def _PF_BS(dx, Nf, Ns, T, H, R, Yo, Xt, dy, xb, B, Q, f, prng):
    Xa, Xf, Xf_mean, Wa = _PF(dx, T, dy, xb, B, Q, R, Nf, f, H, Yo, prng)
    Xs = np.zeros([dx, Ns, T+1])
    ind_smo = sampling_discrete(Wa[:,-1],Ns)
    #ind_smoo = range(Ns)
    Xs[:,:,-1] = Xa[:,ind_smo,-1]
    for t in range(T-1,-1,-1):
        for i in range(Ns):
            innov = np.tile(Xs[:,i,t+1], (Nf,1)).T - Xf_mean[:,:,t+1]
            #const = np.sqrt(2*np.pi*np.linalg.det(Q))
            logmax = np.max(-.5 *np.sum(innov.T.dot(inv(Q))*innov.T,1))
            wei_res = (np.exp(-.5 *np.sum(innov.T.dot(inv(Q))*innov.T,1) -logmax))*Wa[:,t]
            Ws = wei_res/np.sum(wei_res)
            ind_smo[i] = sampling_discrete(Ws,1)
        Xs[:,:,t] = Xa[:,ind_smo,t]
    return Xs, Xa, Xf

def PF_BS(Yo,Xt,Q,f,H,R,xb,B,dx,dy, Nf, Ns,T,prng):
    Xs, Xa, Xf = _PF_BS(dx, Nf, Ns, T, H, R, Yo, Xt, dy, xb, B, Q, f, prng)
    res = {'smoothed_ensemble': Xs,
           'analysis_ensemble': Xa,
           'forecast_ensemble': Xf,
           'loglikelihood'    : _likelihood(Xf, Yo, H, R),
           'RMSE'             : RMSE(Xt - Xs.mean(1))}

    return res

def PF_BS_EM(Yo,Xt,Q,f,H,R,xb,B,dx,dy, Nf, Ns,T,nIter,gam0,estimateQ,estimateR,estimateX0, structQ, structR,baseQ,baseR, prng):
    loglik = np.zeros(nIter)
    rmse_em = np.zeros(nIter)

    Q_all  = np.zeros(np.r_[Q.shape,  nIter+1])
    R_all  = np.zeros(np.r_[R.shape,  nIter+1])
    B_all  = np.zeros(np.r_[B.shape,  nIter+1])
    xb_all = np.zeros(np.r_[xb.shape, nIter+1])
    Xs_all = np.zeros([dx,Ns,T+1,nIter+1])
    
    Q_all[:,:,0] = Q
    R_all[:,:,0] = R
    xb_all[:,0]  = xb
    B_all[:,:,0] = B
    for k in (range(nIter)):
        # Expectation (E)-step
        Xs, Xa, Xf = _PF_BS(dx, Nf, Ns, T, H, R, Yo, Xt, dy, xb, B, Q, f, prng)
        loglik[k] = _likelihood(Xf, Yo, H, R)
        rmse_em[k] = RMSE(Xt[:,1:] - Xs[:,:,1:].mean(1))
        # Maximization (M)-step
        xb_new, B_new, Q_new, R_new = _maximize(Xs, Yo, H, f, structQ=structQ, baseQ=baseQ, structR=structR, baseR=baseR)
        if estimateQ:
            Q = Q_new
        if estimateR:
            R = R_new
        if estimateX0:
            xb = xb_new
            B = B_new
	    # Addition (A)-step
        
        gam = gam0[k]
        Q_all[:,:,k+1] = gam*Q + (1-gam)*Q_all[:,:,k] 
        R_all[:,:,k+1] = gam*R + (1-gam)*R_all[:,:,k] 
        xb_all[:,k+1] = gam*xb + (1-gam)*xb_all[:,k] 
        B_all[:,:,k+1] = gam*B + (1-gam)*B_all[:,:,k] 
        '''
        Q_all[:,:,k+1] = Q
        R_all[:,:,k+1] = R
        xb_all[:,k+1] = xb
        B_all[:,:,k+1] = B
        Xs_all[:,:,:,k+1] = Xs
        '''
    res = {'smoothed_ensemble'             : Xs,
           'smoothed_ensemble_all'        : Xs_all,
           'filtered_ensemble'             : Xa,
          'EM_background_state'            : xb_all,
          'EM_background_covariance'       : B_all,
          'EM_model_noise_covariance'      : Q_all,
          'EM_observation_noise_covariance': R_all,
          'loglikelihood'                  : loglik,
          'RMSE'                           : rmse_em,
          }
    return res
